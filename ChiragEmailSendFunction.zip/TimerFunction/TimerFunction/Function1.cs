using System;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using TimerFunction.Models;

namespace TimerFunction
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static void Run([TimerTrigger("0 30 20 * * *")]TimerInfo myTimer, ILogger log)
        {
            if(myTimer.IsPastDue)
            {
                log.LogInformation("Timer is running late!");
            }
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            Execute();
        }

        private static void Execute()
        {
            TableManager tableManager = new TableManager("ChiragInfo");
            List<Employee> employees = tableManager.employees();
            Console.WriteLine("Registered Employees");
            foreach (Employee employee in employees)
            {
                Console.WriteLine(employee.PartitionKey + " " + employee.RowKey);
            }
            string EmailID = "HR@abc.com";
            //Write Logic To Send Mail
            Console.WriteLine("Email Sent To: " + EmailID + " at: " + DateTime.Now);
        }
    }
}
