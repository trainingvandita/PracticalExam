﻿using Azure;
using Azure.AI.TextAnalytics;
using System;
using System.IO;

namespace TextAnalysisDemo
{
    public class Program
    {

        private static readonly AzureKeyCredential credentials = new AzureKeyCredential("53b6474553ed4fecba63bca407cb249d");
        private static readonly Uri endpoint = new Uri("https://malavtextanalysis.cognitiveservices.azure.com/");
        static void Main(string[] args)
        {
            var client = new TextAnalyticsClient(endpoint, credentials);
            Console.WriteLine("This aplication will do text analysis of all text files inside the provided folder path");
	    Console.WriteLine("Create Any 5 Language Text File On That Folder");
            Console.Write("Enter Folder path(i.e. B:\\Demo): ");
            string path = Console.ReadLine();
            DirectoryInfo d = new DirectoryInfo(@path);
            FileInfo[] Files = d.GetFiles("*.txt");
            foreach (FileInfo file in Files)
            {
                using (StreamReader streamReader = File.OpenText(file.FullName))
                {
                    string text = streamReader.ReadToEnd();
                    Console.WriteLine("File Name: " + file.Name + "\n");
                    LanguageDetectionExample(client, text);
                    KeyPhraseExtractionExample(client, text);
                }
            }
            Console.Write("Press any key to exit.");
            Console.ReadKey();
        }
        #region 
        /// <summary>
        /// LanguageDetection
        /// </summary>
        /// <param name="client"></param>
        /// <param name="text"></param>
        static void LanguageDetectionExample(TextAnalyticsClient client, string text)
        {
            DetectedLanguage detectedLanguage = client.DetectLanguage(text);
            Console.WriteLine("Detected Language:");
            Console.WriteLine($"\t{detectedLanguage.Name},\tISO-6391: {detectedLanguage.Iso6391Name}\n");
        }
        #endregion
        #region 
        /// <summary>
        /// KeyPhrase
        /// </summary>
        /// <param name="client"></param>
        /// <param name="text"></param>
        static void KeyPhraseExtractionExample(TextAnalyticsClient client, string text)
        {
            var response = client.ExtractKeyPhrases(text);
            Console.WriteLine("Key phrases:");

            foreach (string keyphrase in response.Value)
            {
                Console.WriteLine($"\t{keyphrase}\n");
            }
        }
        #endregion
    }
}
