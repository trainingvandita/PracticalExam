﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TimmerFunction.Data;

namespace TimmerFunction
{
    public class TableManager
    {

        private CloudTable EmployeeTable;
        public TableManager(string TableName)
        {
            if (string.IsNullOrEmpty(TableName))
            {
                throw new ArgumentNullException("TableName", "Table Name can't be empty");
            }
            try
            {
                EmployeeTable = CreateTable(TableName);
            }
            catch (Exception ExceptionObj)
            {
                throw ExceptionObj;
            }
        }

        public CloudStorageAccount CreateStorageAccountFromConnectionString(string storageConnectionString)
        {
            CloudStorageAccount storageAccount;
            try
            {
                storageAccount = CloudStorageAccount.Parse(storageConnectionString);
            }
            catch (FormatException FormatExceptionObj)
            {
                throw FormatExceptionObj;
            }
            catch (ArgumentException ArgumentExceptionObj)
            {
                throw ArgumentExceptionObj;
            }
            return storageAccount;
        }

        public CloudTable CreateTable(string tableName)
        {
            string ConnectionString = "DefaultEndpointsProtocol=https;AccountName=training2blobstorage;AccountKey=d4swk28SyaP0RkzEssi2Q39Zsg6+rFQ8bv/UvzYfgwHXIqbuYjY1yrUWXXoH50YdTuipEZhnwQ+JS93TMNFRCg==;EndpointSuffix=core.windows.net";
            CloudStorageAccount storageAccount = CreateStorageAccountFromConnectionString(ConnectionString);
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            tableClient.TableClientConfiguration.UseRestExecutorForCosmosEndpoint = true;
            CloudTable table = tableClient.GetTableReference(tableName);
            table.CreateIfNotExists();
            return table;
        }

       
        public List<Employee> employees()
        {
            List<Employee> employees = new List<Employee>();
            try
            {
                TableQuery<Employee> query = new TableQuery<Employee>();
                employees = EmployeeTable.ExecuteQuery(query).ToList();
                return employees;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return employees;
            }
        }
    }
}
