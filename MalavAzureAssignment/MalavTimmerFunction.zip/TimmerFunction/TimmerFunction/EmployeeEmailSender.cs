using System;
using System.Collections.Generic;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using TimmerFunction.Data;

namespace TimmerFunction
{
    public static class EmployeeEmailSender
    {
        [FunctionName("EmployeeEmailSender")]
        public static void Run([TimerTrigger("0 30 9 * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            Console.Write("Timmer Function Called at 9.30 AM EveryDay");
            Execute();
           
        }
      
    
    private static void Execute()
    {
        TableManager tableManager = new TableManager("MalavEmployeeDetails");
        List<Employee> employees = tableManager.employees();
        Console.WriteLine("Registered Employees");
        foreach (Employee employee in employees)
        {
            Console.WriteLine(employee.FirstName + " " + employee.LastName);
        }
        string EmailID = "HR@abc.com";
        //Write Logic To Send Mail
        Console.WriteLine("Email Sent From: " + EmailID + " at: " + DateTime.Now);
    }
}
}
