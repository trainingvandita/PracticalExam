﻿using Microsoft.Azure.Cosmos.Table;
using System.ComponentModel.DataAnnotations;

namespace AzureWebApp.Models
{
    public class Employee : TableEntity
    {
        public Employee()
        {
        }

        public Employee(string lastName, string firstName)
        {
            PartitionKey = lastName;
            RowKey = firstName;
        }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }
        public string ResumeUrl { get; set; }
    }
}