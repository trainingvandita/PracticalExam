﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace TimerFunction.Models
{
    public class Employee : TableEntity
    {
        public Employee()
        {
        }

        public Employee(string lastName, string firstName)
        {
            PartitionKey = lastName;
            RowKey = firstName;
        }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public string Address { get; set; }
        public string Path { get; set; }
    }
}
