using System;
using System.Collections.Generic;
using Email.Model;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace Email
{
    public static class Function1
    {
        [FunctionName("Function1")]
        public static void Run(
            [TimerTrigger("0 * * * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            Execute();

        }
        private static void Execute()
        {
            BlobManager BManagerObj = new BlobManager("AmiEmployeeTable");
            List<Employee> SutdentListObj = BManagerObj.RetrieveEntity();
            foreach (var singleData in SutdentListObj)
                Console.WriteLine(singleData.RowKey + " " + singleData.PartitionKey + " " + $"{ DateTime.Now}");
            string EmailID = "HR@abc.com";
            Console.WriteLine("Email Sent To:" + EmailID + "at:" + DateTime.Now);

        }
    }
}
