using System;
using System.Collections.Generic;
using EmailNotificationFunction.Model;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace EmailNotificationFunction
{
    public static class AzureEmailFunction
    {
        [FunctionName("AzureEmailFunction")]
        public static void Run([TimerTrigger("0 35 19 * * *")]TimerInfo myTimer, ILogger log)
        {
            log.LogInformation($"C# Timer trigger function executed at: {DateTime.Now}");
            Execute();
          
        }

        private static void Execute()
        {
            TableManager TableManagerObj = new TableManager("DhartiAssignmentEmployeeTable");
            List<Employee> EmployeeListObj = TableManagerObj.RetrieveEntity();
            Console.WriteLine("List of Registered Employees");
            foreach (var singleData in EmployeeListObj)
                Console.WriteLine(singleData.RowKey + " " + singleData.PartitionKey + " " + $"{ DateTime.Now}");
            string EmailID = "HR@abc.com";
            Console.WriteLine("Email Sent To:" + EmailID + "at:" + DateTime.Now);
        }
    }
}
