﻿
using EmailNotificationFunction.Model;
using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmailNotificationFunction
{
    public class TableManager
    {

        // private property  
        private CloudTable table;

        // Constructor   
        public TableManager(string _CloudTableName)
        {
            if (string.IsNullOrEmpty(_CloudTableName))
            {
                throw new ArgumentNullException("Table", "Table Name can't be empty");
            }
            try
            {
                string ConnectionString = "DefaultEndpointsProtocol=https;AccountName=training2blobstorage;AccountKey=d4swk28SyaP0RkzEssi2Q39Zsg6+rFQ8bv/UvzYfgwHXIqbuYjY1yrUWXXoH50YdTuipEZhnwQ+JS93TMNFRCg==;EndpointSuffix=core.windows.net";
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(ConnectionString);
                CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

                table = tableClient.GetTableReference(_CloudTableName);
                table.CreateIfNotExists();
            }
            catch (StorageException StorageExceptionObj)
            {
                throw StorageExceptionObj;
            }
            catch (Exception ExceptionObj)
            {
                throw ExceptionObj;
            }
        }

        public List<Employee> RetrieveEntity()
        {
            List<Employee> DataList = new List<Employee>();
            try
            {
                // Create the Table Query Object for Azure Table Storage  
                TableQuery<Employee> Query = new TableQuery<Employee>();
                DataList = table.ExecuteQuery(Query).ToList();
                return DataList;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return DataList;
            }
        }



    }
}
