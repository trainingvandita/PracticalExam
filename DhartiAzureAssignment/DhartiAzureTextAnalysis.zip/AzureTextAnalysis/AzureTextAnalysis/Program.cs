﻿using System;
using System.IO;
using Azure.AI.TextAnalytics;
namespace AzureTextAnalysis
{
    class Program
    {
        private static readonly TextAnalyticsApiKeyCredential credentials = new TextAnalyticsApiKeyCredential("4ed78e1f1516463182cb697b98609c50");
        private static readonly Uri endpoint = new Uri("https://training1textanalytics.cognitiveservices.azure.com/");
        static void Main(string[] args)
        {
            var client = new TextAnalyticsClient(endpoint, credentials);
            Console.WriteLine("This aplication will do text analysis of all text files inside the provided folder path");
            Console.Write("Enter Folder path(i.e. C:\\filesfoldername): ");
            string path = Console.ReadLine();
            DirectoryInfo d = new DirectoryInfo(@path);
            FileInfo[] Files = d.GetFiles("*.txt");
            foreach (FileInfo file in Files)
            {
                using (StreamReader streamReader = File.OpenText(file.FullName))
                {
                    string text = streamReader.ReadToEnd();
                    Console.WriteLine("File Name: " + file.Name + "\n");
                    LanguageDetect(client, text);
                    KeyPhraseExtract(client, text);
                }
            }
            Console.Write("Press any key to exit.");
            Console.ReadKey();
        }
        static void LanguageDetect(TextAnalyticsClient client, string text)
        {
            DetectedLanguage detectedLanguage = client.DetectLanguage(text);
            Console.WriteLine("Language:");
            Console.WriteLine($"\t{detectedLanguage.Name},\tISO-6391: {detectedLanguage.Iso6391Name}\n");
        }
        static void KeyPhraseExtract(TextAnalyticsClient client, string text)
        {
            var response = client.ExtractKeyPhrases(text);
            Console.WriteLine("Key phrases:");

            foreach (string keyphrase in response.Value)
            {
                Console.WriteLine($"\t{keyphrase}\n");
            }
        }
    }
}

